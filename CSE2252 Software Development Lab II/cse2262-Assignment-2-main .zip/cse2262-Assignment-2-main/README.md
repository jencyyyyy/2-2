# cse2262-Assignment-2
Server Side Software Development 


-> npm init <br>
-> npx express-generator / npm i express <br>
-> npm install <br>
-> npm install --save-dev nodemon <br>

change package.json "start ": "nodemon ./bin/www (npm start) <br>

-> npm i mongoose <br>
# Caution: 
1. Database Connection (Mongo compass) 
2. Port Numeber 
